package com.lv.rxdemo.webview;

import android.content.Context;

/**
 * Created by Lv on 2016/4/3.
 */
public class JavaScriptObject {

    Context mContext;

    public JavaScriptObject(Context mContext) {
        this.mContext = mContext;
    }

}
