package com.lv.rxdemo.config;

/**
 * Created by Lv on 2016/3/23.
 */
public class Constant {
    //主接口
    public static final String MAIN_URL = "http://m.bdhome.cn/";
    //3D设计方案
    public static final String MODEL_DESIGN_URL = "/wap_listDesignJSON.action";
    //图片展示
    public static final String GETIMAGE_URL = "http://images.bdhome.cn/bdhomeimage/";

    public static final String GITHUB_URL = "https://github.com/lv910929/RxDemo";

    public static final String MY_GITHUB_URL = "https://github.com/lv910929";

    public static final String WEIBO_URL = "http://weibo.com/u/1793602270";

}
