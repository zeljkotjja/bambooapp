package com.lv.rxdemo.viewmodel;

import android.content.Context;

/**
 * Created by Lv on 2016/10/11.
 */

public class WebViewModel {

    private Context context;

    public WebViewModel(Context context) {
        this.context = context;
    }
}
